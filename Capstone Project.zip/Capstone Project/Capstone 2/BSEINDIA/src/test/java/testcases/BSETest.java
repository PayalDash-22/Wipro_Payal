package testcases;

import org.testng.annotations.Test;
import pages.*;
import testscripts.BaseTest;

public class BSETest extends BaseTest {

	@Test
	public void fullWorkflow() {
		String url = prop.getProperty("baseUrl");
		String excelPath = "src/test/resources/data/instrument_data.xlsx";

		LoginPage loginPage = new LoginPage(driver);
		MarketWatchPage marketPage = new MarketWatchPage(driver);
		IndexHeatMapPage heatMapPage = new IndexHeatMapPage(driver);
		TrainingAndCertificationsPage tandc = new TrainingAndCertificationsPage(driver);
		loginPage.openHomePage(url);
		marketPage.captureInstrumentsToExcel(excelPath);
		heatMapPage.analyzeIndexes();
		tandc.findRecommendedCourses();
	}
}
