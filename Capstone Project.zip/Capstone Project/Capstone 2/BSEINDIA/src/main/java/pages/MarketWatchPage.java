package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.ExcelUtils;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

public class MarketWatchPage {
	WebDriver driver;

	@FindBy(xpath = "//ul[@role='tablist']//a[@id='mwatch']")
	WebElement marketWatchLink;

	@FindBy(xpath = "//div[@id='mktwatch']//div[1]//table[1]//tbody")
	WebElement tableHeaderRow;

	@FindBy(xpath = "//*[@id=\"myimg\"]/div/div/div[1]/button") // Replace with actual XPath of the popup close button
	WebElement popupCloseButton;

	public MarketWatchPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void captureInstrumentsToExcel(String filePath) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// Close the popup if displayed
		if (popupCloseButton.isDisplayed()) {
			popupCloseButton.click();
		}

		// Click on MarketWatch link
		wait.until(ExpectedConditions.elementToBeClickable(marketWatchLink)).click();

		List<List<String>> data = new ArrayList<>();
		// Capture table headings
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		List<WebElement> headerCells = tableHeaderRow.findElements(By.tagName("th"));
		List<String> headerData = new ArrayList<>();
		for (WebElement headerCell : headerCells) {
			headerData.add(headerCell.getText());
		}
		data.add(headerData);

		// Re-locate the rows dynamically to avoid stale element references
		List<WebElement> rows = wait.until(ExpectedConditions
				.presenceOfAllElementsLocatedBy(By.xpath("//div[@id=\"mktwatch\"]//div[1]//table//tbody//tr")));

		for (WebElement row : rows) {
			try {
				// Re-locate columns dynamically for each row
				List<WebElement> cols = row.findElements(By.tagName("td"));
				List<String> rowData = new ArrayList<>();
				for (WebElement col : cols) {
					rowData.add(col.getText());
				}
				data.add(rowData);
			} catch (StaleElementReferenceException e) {
				// Handle stale element exception by re-locating the row
				rows = driver.findElements(By.xpath("//div[@id=\"mktwatch\"]//div[1]//table//tbody//tr"));
			}
		}

		// Normalize headers by removing newline characters
		List<String> normalizedHeaders = headerData.stream().map(header -> header.replace("\n", " ").trim()) // Replace
																												// newline
																												// characters
																												// and
																												// trim
																												// spaces
				.collect(Collectors.toList());

		System.out.println("Normalized Headers: " + normalizedHeaders); // Debugging: Print normalized headers

		int typeOfInstrumentIndex = normalizedHeaders.indexOf("Type of Instrument");
		int underlyingIndex = normalizedHeaders.indexOf("Underlying");
		final int[] notionalTurnoverIndex = { -1 }; // Use an array to store the index

		// Use partial matching for "Notional Turnover"
		for (int i = 0; i < normalizedHeaders.size(); i++) {
			if (normalizedHeaders.get(i).toLowerCase().contains("notional turnover")) {
				notionalTurnoverIndex[0] = i;
				break;
			}
		}

		if (typeOfInstrumentIndex == -1 || underlyingIndex == -1 || notionalTurnoverIndex[0] == -1) {
			throw new RuntimeException(
					"Columns 'Type of Instrument', 'Underlying', or 'Notional Turnover' not found in the table headers.");
		}

		// Group data by "Type of Instrument" and "Underlying"
		Map<String, Map<String, List<List<String>>>> groupedData = data.stream().skip(1) // Skip the header row
				.filter(row -> row.size() > Math.max(typeOfInstrumentIndex, underlyingIndex)) // Ensure row has enough
																								// columns
				.filter(row -> !row.get(typeOfInstrumentIndex).isEmpty() && !row.get(underlyingIndex).isEmpty()) // Skip
																													// rows
																													// with
																													// empty
																													// values
				.collect(Collectors.groupingBy(row -> row.get(typeOfInstrumentIndex), // Group by Type of Instrument
						Collectors.groupingBy(row -> row.get(underlyingIndex)) // Group by Underlying within Type of
																				// Instrument
				));

		// Debugging: Print grouped data
		System.out.println("Grouped Data:");
		groupedData.forEach((type, underlyingMap) -> {
			System.out.println("Type of Instrument: " + type);
			underlyingMap.forEach((underlying, rows1) -> {
				System.out.println("  Underlying: " + underlying + ", Rows: " + rows1);
			});
		});

		// Find the highest Notional Turnover for each group
		Map<String, Map<String, String>> highestNotionalTurnover = new HashMap<>();
		for (Map.Entry<String, Map<String, List<List<String>>>> typeEntry : groupedData.entrySet()) {
			String typeOfInstrument = typeEntry.getKey();
			Map<String, String> underlyingMaxTurnover = new HashMap<>();
			for (Map.Entry<String, List<List<String>>> underlyingEntry : typeEntry.getValue().entrySet()) {
				String underlying = underlyingEntry.getKey();
				List<List<String>> rows1 = underlyingEntry.getValue();

				// Find the row with the highest Notional Turnover
				Optional<List<String>> maxRow = rows1.stream().filter(row -> {
					try {
						// Validate that the value is numeric
						Double.parseDouble(row.get(notionalTurnoverIndex[0]).replace(",", "").trim());
						return true;
					} catch (NumberFormatException | IndexOutOfBoundsException e) {
						// Skip rows with invalid or missing values
						return false;
					}
				}).max(Comparator.comparingDouble(
						row -> Double.parseDouble(row.get(notionalTurnoverIndex[0]).replace(",", "").trim())));

				maxRow.ifPresent(row -> underlyingMaxTurnover.put(underlying, row.get(notionalTurnoverIndex[0])));
			}
			highestNotionalTurnover.put(typeOfInstrument, underlyingMaxTurnover);
		}

		// Print the highest Notional Turnover for each group
		System.out.println("Highest Notional Turnover:");
		for (Map.Entry<String, Map<String, String>> typeEntry : highestNotionalTurnover.entrySet()) {
			String typeOfInstrument = typeEntry.getKey();
			System.out.println("Type of Instrument: " + typeOfInstrument);
			for (Map.Entry<String, String> underlyingEntry : typeEntry.getValue().entrySet()) {
				String underlying = underlyingEntry.getKey();
				String turnover = underlyingEntry.getValue();
				System.out.println("  Underlying: " + underlying + ", Highest Notional Turnover: " + turnover);
			}
		}

		// Write grouped data to Excel
		List<List<String>> groupedDataForExcel = new ArrayList<>();
		groupedDataForExcel.add(Arrays.asList("Type of Instrument", "Underlying", "Highest Notional Turnover"));

		for (Map.Entry<String, Map<String, String>> typeEntry : highestNotionalTurnover.entrySet()) {
			String typeOfInstrument = typeEntry.getKey();
			for (Map.Entry<String, String> underlyingEntry : typeEntry.getValue().entrySet()) {
				String underlying = underlyingEntry.getKey();
				String turnover = underlyingEntry.getValue();
				groupedDataForExcel.add(Arrays.asList(typeOfInstrument, underlying, turnover));
			}
		}

		try {
			System.out.println("Writing grouped data to Excel...");
			ExcelUtils.writeToExcel(filePath, groupedDataForExcel);
			System.out.println("Data successfully written to Excel.");
		} catch (Exception e) {
			System.err.println("Error writing to Excel: " + e.getMessage());
			e.printStackTrace();
		}
	}
}