package pages;

import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TrainingAndCertificationsPage {
	WebDriver driver;

	@FindBy(linkText = "Menu")
	WebElement menu;

	@FindBy(linkText = "Training & Certification") // Replace with actual XPath for the menu
	WebElement trainingMenu;

	@FindBy(id = "ddlDomains") // Replace with actual ID for the Domain field
	WebElement domainDropdown;

	@FindBy(id = "ddlMode") // Replace with actual ID for the Mode field
	WebElement modeDropdown;

	@FindBy(id = "ddlLocation") // Replace with actual ID for the Location field
	WebElement locationDropdown;

	@FindBy(xpath = "//button[contains(text(),'Search Courses')]") // Replace with actual XPath for the Search button
	WebElement searchButton;

	@FindBy(xpath = "//div[@class='course-card']") // Replace with actual XPath for course cards
	List<WebElement> courseCards;

	public TrainingAndCertificationsPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void findRecommendedCourses() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// Navigate to "Training and Certifications" menu
		wait.until(ExpectedConditions.elementToBeClickable(menu)).click();
		wait.until(ExpectedConditions.elementToBeClickable(trainingMenu)).click();

		// Handle new window
		String originalWindow = driver.getWindowHandle();
		Set<String> allWindows = driver.getWindowHandles();
		for (String window : allWindows) {
			if (!window.equals(originalWindow)) {
				driver.switchTo().window(window);
				break;
			}
		}

		// Apply filters
		Select domainSelect = new Select(domainDropdown);
		domainSelect.selectByVisibleText("Technical");

		Select modeSelect = new Select(modeDropdown);
		modeSelect.selectByVisibleText("Online");

		Select locationSelect = new Select(locationDropdown);
		locationSelect.selectByVisibleText("Mumbai");

		wait.until(ExpectedConditions.elementToBeClickable(searchButton)).click();

		// Wait for course cards to load
		// wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//div[@class='course-card']")));

		// Extract course details
		List<Map<String, String>> courses = new ArrayList<>();
		for (WebElement card : courseCards) {
			try {
				String courseName = card.findElement(By.xpath(".//h3[@class='course-name']")).getText(); // Replace with
																											// actual
																											// XPath for
																											// course
																											// name
				String durationText = card.findElement(By.xpath(".//span[@class='course-duration']")).getText(); // Replace
																													// with
																													// actual
																													// XPath
																													// for
																													// duration
				String priceText = card.findElement(By.xpath(".//span[@class='course-price']")).getText(); // Replace
																											// with
																											// actual
																											// XPath for
																											// price

				// Parse duration and price
				int duration = Integer.parseInt(durationText.replaceAll("[^0-9]", ""));
				double price = Double.parseDouble(priceText.replaceAll("[^0-9.]", ""));

				Map<String, String> courseDetails = new HashMap<>();
				courseDetails.put("Name", courseName);
				courseDetails.put("Duration", String.valueOf(duration));
				courseDetails.put("Price", String.valueOf(price));
				courses.add(courseDetails);
			} catch (NoSuchElementException e) {
				System.err.println("Error extracting course details: " + e.getMessage());
			}
		}

		// Filter courses with duration <= 6 days
		List<Map<String, String>> shortCourses = courses.stream()
				.filter(course -> Integer.parseInt(course.get("Duration")) <= 6).collect(Collectors.toList());

		// Find course(s) with the lowest price
		OptionalDouble lowestPrice = shortCourses.stream()
				.mapToDouble(course -> Double.parseDouble(course.get("Price"))).min();

		List<Map<String, String>> recommendedCourses = shortCourses.stream()
				.filter(course -> Double.parseDouble(course.get("Price")) == lowestPrice.orElse(Double.MAX_VALUE))
				.collect(Collectors.toList());

		// Print recommended courses
		System.out.println("Recommended Courses:");
		recommendedCourses.forEach(course -> System.out.println("Name: " + course.get("Name") + ", Duration: "
				+ course.get("Duration") + " days, Price: ₹" + course.get("Price")));

		// Switch back to the original window
		driver.switchTo().window(originalWindow);
	}
}