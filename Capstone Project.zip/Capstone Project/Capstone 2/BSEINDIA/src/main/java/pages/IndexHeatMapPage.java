package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.*;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

public class IndexHeatMapPage {
	WebDriver driver;

	@FindBy(linkText = "Markets") // Replace with actual XPath for the Markets tab
	WebElement marketsTab;

	public IndexHeatMapPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void analyzeIndexes() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// Navigate to the Markets tab
		wait.until(ExpectedConditions.elementToBeClickable(marketsTab)).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(80));

		// Wait for the index boxes to be visible
		wait.until(ExpectedConditions
				.presenceOfAllElementsLocatedBy(By.xpath("//div[@class=' heatamaparea whitebox']//div[1]//div[2]")));

		// Extract index data
		List<Map<String, String>> indexData = new ArrayList<>();
		List<WebElement> indexBoxes = driver
				.findElements(By.xpath("//div[@class=' heatamaparea whitebox']//div[1]//div[2]"));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		System.out.println("Number of index boxes found: " + indexBoxes.size());

		for (WebElement box : indexBoxes) {
			try {
				// Extract data from each index box
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
				String indexName = box
						.findElement(
								By.xpath("//div[@id='carouselExampleIndicators']//div[@class='wraptext ng-binding']"))
						.getText();
				String change = box
						.findElement(By.xpath("//div[@id='carouselExampleIndicators']//div[@class='ng-binding']"))
						.getText();

				// Debugging: Print extracted values
				System.out.println("Extracted Index Name: " + indexName);
				System.out.println("Extracted Change: " + change);

				Map<String, String> indexInfo = new HashMap<>();
				indexInfo.put("IndexName", indexName);
				indexInfo.put("Change", change);
				indexData.add(indexInfo);
			} catch (StaleElementReferenceException e) {
				System.err.println("StaleElementReferenceException occurred. Re-locating index boxes...");
				indexBoxes = driver.findElements(By.xpath("//div[@class=' heatamaparea whitebox']//div[1]//div[2]"));
			} catch (NoSuchElementException e) {
				System.err.println("NoSuchElementException occurred. Skipping this box...");
			}
		}

		// Group indexes into gained and lost categories
		List<Map<String, String>> gainedIndexes = indexData.stream().filter(index -> {
			try {
				return Double.parseDouble(index.get("Change").replaceAll("[^0-9.-]", "")) > 0;
			} catch (NumberFormatException e) {
				return false; // Skip invalid data
			}
		}).collect(Collectors.toList());

		List<Map<String, String>> lostIndexes = indexData.stream().filter(index -> {
			try {
				return Double.parseDouble(index.get("Change").replaceAll("[^0-9.-]", "")) < 0;
			} catch (NumberFormatException e) {
				return false; // Skip invalid data
			}
		}).collect(Collectors.toList());

		// Find the index with the highest gain
		Optional<Map<String, String>> highestGainIndex = gainedIndexes.stream().max(Comparator
				.comparingDouble(index -> Double.parseDouble(index.get("Change").replaceAll("[^0-9.-]", ""))));

		// Find the index with the highest loss
		Optional<Map<String, String>> highestLossIndex = lostIndexes.stream().min(Comparator
				.comparingDouble(index -> Double.parseDouble(index.get("Change").replaceAll("[^0-9.-]", ""))));

		// Find indexes that gained more than 50 points
		List<Map<String, String>> indexesGainedMoreThan50 = gainedIndexes.stream()
				.filter(index -> Double.parseDouble(index.get("Change").replaceAll("[^0-9.-]", "")) > 50)
				.collect(Collectors.toList());

		// Print results
		System.out.println("Indexes that gained:");
		gainedIndexes
				.forEach(index -> System.out.println(index.get("IndexName") + " - " + index.get("Change") + " points"));

		System.out.println("Indexes that lost:");
		lostIndexes
				.forEach(index -> System.out.println(index.get("IndexName") + " - " + index.get("Change") + " points"));

		highestGainIndex.ifPresent(index -> System.out.println(
				"Index with highest gain: " + index.get("IndexName") + " - " + index.get("Change") + " points"));
		highestLossIndex.ifPresent(index -> System.out.println(
				"Index with highest loss: " + index.get("IndexName") + " - " + index.get("Change") + " points"));

		System.out.println("Indexes that gained more than 50 points:");
		indexesGainedMoreThan50
				.forEach(index -> System.out.println(index.get("IndexName") + " - " + index.get("Change") + " points"));
	}
}