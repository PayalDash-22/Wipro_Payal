package testscripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import java.util.Properties;
import utils.ConfigReader;

public class BaseTest {
	public WebDriver driver;
	public Properties prop;

	@BeforeClass
	public void setUp() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		prop = ConfigReader.loadProperties("src/test/resources/config/config.properties");
	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
