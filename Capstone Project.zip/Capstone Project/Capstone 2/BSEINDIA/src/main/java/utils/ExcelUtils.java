package utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.List;

public class ExcelUtils {

	public static void writeToExcel(String filePath, List<List<String>> data) {
		File file = new File(filePath);
		String tempFilePath = filePath.replace(".xlsx", "_temp.xlsx"); // Temporary file path

		try {
			Workbook workbook = new XSSFWorkbook();
			Sheet sheet = workbook.createSheet("MarketWatch Data");

			// Write data to the sheet
			for (int i = 0; i < data.size(); i++) {
				Row row = sheet.createRow(i);
				List<String> rowData = data.get(i);
				for (int j = 0; j < rowData.size(); j++) {
					Cell cell = row.createCell(j);
					cell.setCellValue(rowData.get(j));
				}
			}

			// Write workbook to temporary file
			try (FileOutputStream fos = new FileOutputStream(tempFilePath)) {
				workbook.write(fos);
			}

			workbook.close();

			// Replace original file with temporary file
			File tempFile = new File(tempFilePath);
			if (file.exists() && !file.delete()) {
				throw new IOException("Failed to delete the original file: " + filePath);
			}
			if (!tempFile.renameTo(file)) {
				throw new IOException("Failed to rename temporary file to original file: " + filePath);
			}

		} catch (IOException e) {
			System.err.println("Error writing to Excel file: " + e.getMessage());
			e.printStackTrace();
		}
	}
}