package pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;

import objectrepository.Locators;

public class OneWayTripPage {
	WebDriver driver;
	WebDriverWait wait;
	ExtentTest test;

	public OneWayTripPage(WebDriver driver, ExtentTest test) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		this.test = test;
	}

	public void Closebt() {
		wait.until(ExpectedConditions.elementToBeClickable(Locators.closeBt));
		WebElement closebutton = driver.findElement(Locators.closeBt);
		closebutton.click();
	}

//public void popup() {
//	wait.until(ExpectedConditions.elementToBeClickable(Locators.Popup));
//	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//	WebElement popup=driver.findElement(Locators.Popup);
//	popup.click();
//}
	public void Oneway() {
		WebElement Oneway = driver.findElement(Locators.oneway);
		Oneway.click();
	}

	public void From() {
		WebElement From = driver.findElement(Locators.From);
		From.click();
		driver.findElement(Locators.FromIp).sendKeys("Hyd");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		WebElement clik = driver.findElement(Locators.FromPlace);
		clik.click();

	}

	public void To() {
		WebElement To = driver.findElement(Locators.To);
		To.click();
		WebElement toip = driver.findElement(Locators.ToIp);
		toip.sendKeys("vga");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(Locators.ToPlace).click();

	}

	public void Departure() {
		driver.findElement(Locators.Departure).click();
		driver.findElement(Locators.DepartureDate).click();
	}

	public void TravelDetails() throws InterruptedException {
		driver.findElement(Locators.TC).click();
		// driver.findElement(Locators.Adult).click();
		// driver.findElement(Locators.economy).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(4));
		WebElement abc = driver.findElement(Locators.donebt);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scroll(0,+300)");

		abc.click();
		driver.findElement(Locators.SearchBt).click();
		driver.findElement(Locators.gotit).click();
	}

	public void Cheapest() {

		driver.findElement(Locators.Chepaest).click();
	}

	public void SltCheap() {
		wait.until(ExpectedConditions.elementToBeClickable(Locators.SltCheap));
		WebElement df = driver.findElement(Locators.SltCheap);
		df.click();

		driver.findElement(Locators.BookTkt).click();
	}

	public void Review() {
		Set<String> handles = driver.getWindowHandles();
		List<String> tabs = new ArrayList<>(handles);
		driver.switchTo().window(tabs.get(1)); // Switch to the second tab
		wait.until(ExpectedConditions.visibilityOfElementLocated(Locators.reviewcanc));
	}
}