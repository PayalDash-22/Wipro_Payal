package stepDefinations;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import junit.framework.Assert;
import objectrepository.Locators;
import pages.OneWayTripPage;
import utility.Base;

public class OneWaystepdef {
	WebDriver driver = Base.driver;
	ExtentTest test = Hooks.test;
	OneWayTripPage otp=new OneWayTripPage(driver,test);
	@Given("User is on the homepage")
	public void user_is_on_the_homepage() {
		driver.switchTo().defaultContent(); // Switch back to the main document
	}
	@And("user must close the popup tab")
	public void user_must_close_the_popup_tab() {
	    // Write code here that turns the phrase above into concrete actions
		otp.Closebt();
	}

	@And("user selects onewaytrip")
	public void user_selects_onewaytrip() {
	    // Write code here that turns the phrase above into concrete actions
		otp.Oneway();
	}

	@And("then user selects from and to destinations")
	public void then_user_selects_from_and_to_destinations() {
	    // Write code here that turns the phrase above into concrete actions
		otp.From();
		otp.To();
	}

	@And("selects the departure date")
	public void selects_the_departure_date() {
	    // Write code here that turns the phrase above into concrete actions
		otp.Departure();
	}

	@And("gives the travelling details")
	public void gives_the_travelling_details() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		otp.TravelDetails();
	}

	@And("sorts the flights based on chepaest price")
	public void sorts_the_flights_based_on_chepaest_price() throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		otp.Cheapest();
	}

	@And("selects the cheapest price flight")
	public void selects_the_cheapest_price_flight() {
	    // Write code here that turns the phrase above into concrete actions
		otp.SltCheap();
	}

	@Then("reviews the Ticket")
	public void reviews_the_ticket() {
	    // Write code here that turns the phrase above into concrete actions
		otp.Review();
		Assert.assertTrue(driver.findElement(Locators.reviewcanc).isDisplayed());
	}
}