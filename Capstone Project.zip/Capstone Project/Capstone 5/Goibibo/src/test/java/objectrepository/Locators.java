package objectrepository;

import org.openqa.selenium.By;

public class Locators {
	public static By Popup = By.xpath("//button[@id=\"deny\"]");
	public static By closeBt = By.xpath("//span[@class=\"logSprite icClose\"]");
	public static By oneway = By.xpath("//p[contains(text(),'One-way')]");

	public static By From = By.xpath("//span[contains(text(),'From')]");
	public static By FromIp = By.xpath("//input[@type=\"text\"]");
	public static By FromPlace = By.xpath("//p[contains(text(),'Rajiv Gandhi International Airport')]");

	public static By To = By.xpath("//div[@class=\"sc-12foipm-25 fbAAhv\"]//span[contains(text(),'To')]");
	public static By ToIp = By.xpath("//input[@type=\"text\"]");
	public static By ToPlace = By.xpath("//span[contains(text(),'Vijayawada, India')]");

	public static By Departure = By.xpath("//span[contains(text(),'Departure')]");
	public static By DepartureDate = By.xpath("//div[@aria-label='Mon Jul 21 2025']");

	public static By TC = By.xpath("//div[@class=\"sc-12foipm-20 cOYHtZ\"]");
	public static By economy = By.xpath("//li[contains(text(),'premium economy')]");
	public static By Adult = By.xpath("//div[@class=\"sc-12foipm-47 pZQPB\"]//span[contains(text(),'1')]");
	public static By donebt = By.xpath("//a[contains(text(),'Done')]");
	public static By SearchBt = By.xpath("//span[contains(text(),'SEARCH FLIGHTS')]");

	public static By gotit = By
			.xpath("//*[@id=\"listing-id\"]/div/div[2]/div/div[1]/div[1]/div[2]/div[2]/div/div/div/span");

	public static By Chepaest = By.xpath("//font[contains(text(),'Cheapest')]");

	public static By SltCheap = By.xpath("//span[@data-test='component-buttonText']");

	public static By BookTkt = By.xpath("//div[@class='keen-slider__slide number-slide1 fareFamilyCardWrapper cta-wrapper']//button[@type='button'][normalize-space()='BOOK NOW']\r\n"
		);

	public static By reviewcanc = By
			.xpath("//font[contains(text(),'Cancellation & Date Change Policy')]");
}