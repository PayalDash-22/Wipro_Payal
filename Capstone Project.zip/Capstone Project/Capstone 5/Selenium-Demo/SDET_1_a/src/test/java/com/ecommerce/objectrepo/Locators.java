package com.ecommerce.objectrepo;

import org.openqa.selenium.By;

public class Locators {
	public static By fname = By.xpath("//input[@placeholder='First Name']");
	public static By lname = By.xpath("//input[@placeholder='Last Name']");
	public static By address = By.xpath("//*[@id=\"basicBootstrapForm\"]/div[2]/div/textarea");
	public static By email = By.xpath("//input[@type='email']");
	public static By phonenumber = By.xpath("//input[@type='tel']");
	public static By gender = By.xpath("//input[@value='Male']");
	public static By cricket = By.id("checkbox1");
	public static By movies = By.id("checkbox2");
	public static By hockey = By.id("checkbox3");
	public static By language = By.xpath("//div[@id='msdd']");
	public static By eng = By.linkText("English");
	public static By skills = By.id("Skills");
	public static By country = By.id("countries");
	public static By year = By.id("yearbox");
	public static By month = By.xpath("//select[@placeholder='Month']");
	public static By day = By.id("daybox");
	public static By password = By.id("firstpassword");
	public static By confirmpassword = By.id("secondpassword");
	public static By submit = By.id("submitbtn");
}
