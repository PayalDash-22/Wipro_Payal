package com.ecommerce.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Timeouts;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.ecommerce.objectrepo.Locators;

public class HomePage {
	WebDriver driver;
	WebDriverWait wait;
	ExtentTest test;

	public HomePage(WebDriver driver, ExtentTest test) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		this.test = test;
	}

	public void EnterDetails() throws InterruptedException {
		WebElement fname = driver.findElement(Locators.fname);
		fname.sendKeys("Raju");
		WebElement lname = driver.findElement(Locators.lname);
		lname.sendKeys("Kumar");
		WebElement address = driver.findElement(Locators.address);
		address.sendKeys("Hyd");
		WebElement mail = driver.findElement(Locators.email);
		mail.sendKeys("raju0@gmail.com");
		WebElement mobilenumber = driver.findElement(Locators.phonenumber);
		mobilenumber.sendKeys("9661760718");
		WebElement gender = driver.findElement(Locators.gender);
		gender.click();
		WebElement cric = driver.findElement(Locators.cricket);
		cric.click();
		WebElement mov = driver.findElement(Locators.movies);
		mov.click();
		WebElement hoc = driver.findElement(Locators.hockey);
		//hoc.click();

		WebElement lan = driver.findElement(Locators.language);
		lan.click();
		WebElement eng = driver.findElement(Locators.eng);
		eng.click();
		WebElement skills = driver.findElement(Locators.skills);
		Select select = new Select(skills);
		select.selectByVisibleText("Java");
		WebElement country = driver.findElement(Locators.country);
		Select select1 = new Select(country);
		select1.selectByVisibleText("Select Country");
		WebElement year = driver.findElement(Locators.year);
		Select select2 = new Select(year);
		select2.selectByVisibleText("2002");
		WebElement month = driver.findElement(Locators.month);
		Select select3 = new Select(month);
		select3.selectByVisibleText("July");
		WebElement date = driver.findElement(Locators.day);
		Select select4 = new Select(date);
		select4.selectByVisibleText("1");
		WebElement pwd = driver.findElement(Locators.password);
		pwd.sendKeys("Raju34@");
		WebElement cpwd = driver.findElement(Locators.confirmpassword);
		cpwd.sendKeys("Raju34@");
		WebElement submit = driver.findElement(Locators.submit);
		submit.click();
	}
}