package com.ecommerce.objectrepo;

import org.openqa.selenium.By;

public class Locators {
	public static By iframewithiframe = By.linkText("Iframe with in an Iframe");
}
