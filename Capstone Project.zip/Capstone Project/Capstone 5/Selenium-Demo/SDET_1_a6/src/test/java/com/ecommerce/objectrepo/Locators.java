package com.ecommerce.objectrepo;

import org.openqa.selenium.By;

public class Locators {
	
}
