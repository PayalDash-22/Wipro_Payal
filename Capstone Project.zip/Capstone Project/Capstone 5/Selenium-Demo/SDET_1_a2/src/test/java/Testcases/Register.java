package Testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.ecommerce.pages.HomePage;
import com.ecommerce.stepDefination.Hooks;
import com.ecommerce.utility.Base;

public class Register extends Base {
	WebDriver driver = new ChromeDriver();
	ExtentTest test = Hooks.test;
	HomePage homepage = new HomePage(driver, test);

	@Test
	public void f() throws InterruptedException {
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		homepage.EnterDetails();
	}
    @AfterTest
    public void tearDown() {
        if (driver != null) {
            driver.quit();  // Closes browser and ends WebDriver session
            System.out.println("Browser closed successfully");
        }
    }
}
