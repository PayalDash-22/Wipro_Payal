package com.ecommerce.objectrepo;

import org.openqa.selenium.By;

public class Locators {
	public static By alert1 = By.xpath("//button[@class='btn btn-danger']");
	public static By alert2 = By.linkText("Alert with OK & Cancel");
	public static By btn = By.xpath("//button[@class='btn btn-primary']");
	public static By last = By.linkText("Alert with Textbox");
	public static By button = By.xpath("//button[@class='btn btn-info']");
}
