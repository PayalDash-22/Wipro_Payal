package com.ecommerce.pages;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.ecommerce.objectrepo.Locators;

public class HomePage {
	WebDriver driver;
	WebDriverWait wait;
	ExtentTest test;

	public HomePage(WebDriver driver, ExtentTest test) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		this.test = test;
	}

	public void EnterDetails() throws InterruptedException {
		driver.findElement(Locators.datepicker).click();
		driver.findElement(Locators.date).click();
		driver.findElement(Locators.datepick).click();
		driver.findElement(Locators.dat).click();
	}
}