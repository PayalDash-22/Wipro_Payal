package com.ecommerce.objectrepo;

import org.openqa.selenium.By;

public class Locators {
	public static By datepicker = By.id("datepicker1");
	public static By date = By.xpath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[4]/td[5]/a");
	public static By datepick = By.id("datepicker2");
	public static By dat = By.linkText("22");
}
