package com.ecommerce.objectrepo;

import org.openqa.selenium.By;

public class Locators {
	public static By tabbed = By.xpath("//a[@href='http://www.selenium.dev']//button[@class='btn btn-info'][normalize-space()='click']");
	public static By sepearate=By.linkText("Open New Seperate Windows");
	public static By sepbtn = By.xpath("//button[@class='btn btn-primary']");
	public static By mult = By.linkText("Open Seperate Multiple Windows");
	public static By btton = By.xpath("//button[@onclick='multiwindow()']");
}
