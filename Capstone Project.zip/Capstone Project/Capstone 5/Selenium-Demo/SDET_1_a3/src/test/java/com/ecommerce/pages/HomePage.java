package com.ecommerce.pages;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.ecommerce.objectrepo.Locators;

public class HomePage {
	WebDriver driver;
	WebDriverWait wait;
	ExtentTest test;

	public HomePage(WebDriver driver, ExtentTest test) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		this.test = test;
	}

	public void EnterDetails() throws InterruptedException {
		WebElement a = driver.findElement(Locators.tabbed);
		a.click();
		WebElement b = driver.findElement(Locators.sepearate);
		b.click();
		driver.findElement(Locators.sepbtn).click();
		driver.findElement(Locators.mult).click();
		driver.findElement(Locators.btton).click();
	}
}