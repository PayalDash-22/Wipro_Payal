package utils;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
public static void writetabletoexcel(String filePath,List<List<String>> tableData,String sheetname) {
	Workbook workbook = new XSSFWorkbook();
	Sheet sheet = workbook.createSheet(sheetname);
	
	for(int i=0;i<tableData.size();i++) {
		Row row = sheet.createRow(i);
		List<String>rowData = tableData.get(i);
		for(int j=0;j<rowData.size();j++) {
			row.createCell(j).setCellValue(rowData.get(j));
		}
		
	}
	try(FileOutputStream fileOut = new FileOutputStream(filePath)){
		workbook.write(fileOut);
		workbook.close();
		System.out.println("Data written to excel");
		
	}catch(IOException e) {
		e.printStackTrace();
	}
	
}
}
