package objectrepository;

import org.openqa.selenium.By;

public class Locators {
	public static By closepop =By.xpath("(//button[@class='btn-close'])[1]");
	public static By Marketwatch=By.id("mwatch");
	//public static By marketwatchtable=By.xpath("//div[@id='mktwatch']//div[contains(@class,'fixTableHead')]");
	public static By rows_marketwatch=By.xpath("//tbody[@ng-repeat='id in indexderi.Table']");
	public static By markets=By.xpath("//ul[@class=\"navbar-nav homenav\"]//li[4]");
	public static By losers=By.xpath("//div[contains(@class,'boxred')]");
	public static By gainers=By.xpath("//div[contains(@class,'boxgreen')]");
	
	

}