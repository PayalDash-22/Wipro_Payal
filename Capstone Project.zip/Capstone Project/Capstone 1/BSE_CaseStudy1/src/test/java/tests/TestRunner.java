package tests;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.IndexHeatmapPage;
import pages.MarketWatchPage;
import utils.Base;

public class TestRunner extends Base{
  @BeforeMethod
  public void beforeMethod() {
	  launchBrowser();
	  }
  @Test
  public void f() throws InterruptedException {
	  HomePage homepage = new HomePage(driver);
	  homepage.clicks();
	  MarketWatchPage marketwatchpage = new MarketWatchPage(driver);
	  marketwatchpage.marketwatchCapture();
	  IndexHeatmapPage indexHeatmapPage = new IndexHeatmapPage(driver);
	  indexHeatmapPage.marketclick();
	  indexHeatmapPage.analyzeIndexes();

  }


  @AfterMethod
  public void afterMethod() {
	  if(driver!=null) {
		  driver.quit();
	  }
  }

}
