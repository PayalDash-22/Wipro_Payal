package pages;

import java.io.File;
import java.io.FileInputStream;
import java.text.DecimalFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import objectrepository.Locators;
import utils.ExcelUtils;

public class MarketWatchPage {
    WebDriver driver;
    List<List<String>> tableData = new ArrayList<>();

    public MarketWatchPage(WebDriver driver) {
        this.driver = driver;
    }

    public void marketwatchCapture() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        int maxRowRetries = 3;

        wait.until(ExpectedConditions.presenceOfElementLocated(Locators.rows_marketwatch));
        WebElement table = driver.findElement(Locators.rows_marketwatch);
        Thread.sleep(1000);

        WebElement headerRow = driver.findElement(By.xpath("//tr[th]"));
        List<WebElement> headers = headerRow.findElements(By.xpath(".//th"));
        List<String> columnNames = new ArrayList<>();

        for (WebElement header : headers) {
            String headerText = (String) js.executeScript("return arguments[0].innerText;", header);
            columnNames.add(headerText.trim());
        }

        tableData.add(columnNames);

        int rowCount = driver.findElements(Locators.rows_marketwatch).size();
        System.out.println("Total rows detected in Market Watch Table: " + rowCount);

        for (int rowIndex = 1; rowIndex <= rowCount; rowIndex++) {
            int rowRetryCount = 0;

            while (rowRetryCount < maxRowRetries) {
                try {
                    WebElement row = driver.findElement(By.xpath("//tbody[@ng-repeat='id in indexderi.Table'][" + rowIndex + "]"));
                    List<WebElement> cells = row.findElements(By.xpath(".//th | .//td"));
                    List<String> rowData = new ArrayList<>();

                    for (WebElement cell : cells) {
                        String cellText = (String) js.executeScript("return arguments[0].innerText;", cell);
                        rowData.add(cellText.trim());
                    }

                    if (!tableData.contains(rowData) && !rowData.isEmpty()) {
                        tableData.add(rowData);
                    }

                    break;

                } catch (org.openqa.selenium.StaleElementReferenceException e) {
                    System.out.println("Stale element detected in row " + rowIndex + "! Retrying...");
                    rowRetryCount++;
                    Thread.sleep(2000);
                }
            }

            if (rowRetryCount == maxRowRetries) {
                System.out.println("Skipping row " + rowIndex + " after max retries.");
            }
        }

        ExcelUtils.writetabletoexcel("src/test/resources/data/Marketwatch.xlsx", tableData, "MarketWatch");
        System.out.println("Table data saved successfully!");

        processMarketWatchData("src/test/resources/data/Marketwatch.xlsx");
    }

    public void processMarketWatchData(String filePath) {
        List<List<String>> excelData = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(new File(filePath));
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet("MarketWatch");
            for (Row row : sheet) {
                List<String> rowData = new ArrayList<>();
                for (Cell cell : row) {
                    rowData.add(cell.toString().replace("\r", "").replace("\n", "").trim());
                }
                excelData.add(rowData);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (excelData.isEmpty()) {
            System.out.println("No data found in Excel.");
            return;
        }

        System.out.println("Detected Column Headers: " + excelData.get(0));

        // Dynamic column index detection using contains()
        int typeOfInstrumentIndex = -1, underlyingIndex = -1, notionalTurnoverIndex = -1;
        for (int i = 0; i < excelData.get(0).size(); i++) {
            String colName = excelData.get(0).get(i).replace("\r", "").replace("\n", "").trim();
            
            if (colName.contains("Type of Instrument")) typeOfInstrumentIndex = i;
            if (colName.contains("Underlying")) underlyingIndex = i;
            if (colName.contains("Notional Turnover")) notionalTurnoverIndex = i;
        }

        if (typeOfInstrumentIndex == -1 || underlyingIndex == -1 || notionalTurnoverIndex == -1) {
            System.out.println("Required columns not found in table data.");
            return;
        }

        Map<String, Map<String, Double>> groupedData = new HashMap<>();

        for (int i = 1; i < excelData.size(); i++) {
            List<String> row = excelData.get(i);
            String typeOfInstrument = row.get(typeOfInstrumentIndex).trim();
            String underlying = row.get(underlyingIndex).trim();

            // Handle non-numeric values safely
            double notionalTurnover = 0.0;
            String turnoverString = row.get(notionalTurnoverIndex).replace(",", "").trim();

            if (!turnoverString.equals("--") && !turnoverString.isEmpty()) {
                try {
                    notionalTurnover = Double.parseDouble(turnoverString);
                } catch (NumberFormatException e) {
                    System.out.println("Skipping invalid turnover value: " + turnoverString);
                    continue;
                }
            }

            // **Skip blank instrument entries and zero turnover**
            if (typeOfInstrument.isEmpty() || underlying.isEmpty() || notionalTurnover == 0.0) {
                continue;
            }

         groupedData.computeIfAbsent(typeOfInstrument, k -> new HashMap<>()).merge(underlying, notionalTurnover, Math::max);
        }

        // Formatting large numbers with commas
        DecimalFormat formatter = new DecimalFormat("#,##0.00");

        System.out.println("\nHighest Notional Turnover per Group:");
        groupedData.forEach((type, underlyingMap) -> {
            System.out.println("Instrument: " + type);
            underlyingMap.forEach((underlying, turnover) ->
                System.out.println("  Underlying: " + underlying + " -> Highest Turnover: " + formatter.format(turnover)));
        });
    }
}





