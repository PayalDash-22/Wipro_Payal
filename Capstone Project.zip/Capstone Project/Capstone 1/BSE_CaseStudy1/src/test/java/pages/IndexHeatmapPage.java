package pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import objectrepository.Locators;

public class IndexHeatmapPage {
    WebDriver driver;

public IndexHeatmapPage(WebDriver driver) {
        this.driver = driver;
    }
public void marketclick() {
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
	WebElement market = wait.until(ExpectedConditions.presenceOfElementLocated(Locators.markets));
	market.click();
}

    public void analyzeIndexes() {
        // Locate index boxes (green = gainers, red = losers)
        //List<WebElement> indexBoxes = driver.findElements(By.xpath("//div[contains(@class,'boxred') or contains(@class,'boxgreen')]"));
    	List<WebElement> greenBoxes = driver.findElements(Locators.gainers);
    	List<WebElement> redBoxes = driver.findElements(Locators.losers);

    	// Combine both lists
    	List<WebElement> indexBoxes = new ArrayList<>();
    	indexBoxes.addAll(greenBoxes);
    	indexBoxes.addAll(redBoxes);

        // Lists to categorize indexes
        List<String> gainers = new ArrayList<>();
        List<String> losers = new ArrayList<>();
        List<String> above50PointsGain = new ArrayList<>();
        
        String highestGainer = "";
        String highestLoser = "";
        
        double maxGain = Double.MIN_VALUE;
        double maxLoss = Double.MAX_VALUE;

        for (WebElement box : indexBoxes) {
            String indexData = box.getText();
            String[] lines = indexData.split("\n");

            // Ensure extracted data contains at least the required fields
            if (lines.length >= 3) {
                String indexName = lines[0];
                String changeValueText = lines[2].split(" ")[0].replace(",", "").trim();

                try {
                    double changeValue = Double.parseDouble(changeValueText);

                    // Categorize indexes based on their movement
                    if (changeValue > 0) {
                        gainers.add(indexName);
                        if (changeValue > maxGain) {
                            maxGain = changeValue;
                            highestGainer = indexName;
                        }
                        if (changeValue > 50) {
                            above50PointsGain.add(indexName + " (" + changeValue + ")");
                        }
                    } else {
                        losers.add(indexName);
                        if (changeValue < maxLoss) {
                            maxLoss = changeValue;
                            highestLoser = indexName;
                        }
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Skipping invalid index data: " + indexName + " -> " + changeValueText);
                }
            }
        }

        // Display grouped indexes
        System.out.println("\nIndexes that gained: " + gainers);
        System.out.println("Indexes that lost: " + losers);

        // Display highest gain and loss indexes
        System.out.println("\nHighest Gain Index: " + highestGainer + " (" + maxGain + ")");
        System.out.println("Highest Loss Index: " + highestLoser + " (" + maxLoss + ")");

        // Display indexes with more than 50 points gain
        System.out.println("\nIndexes with more than 50 points gain: " + above50PointsGain);
    }
}

