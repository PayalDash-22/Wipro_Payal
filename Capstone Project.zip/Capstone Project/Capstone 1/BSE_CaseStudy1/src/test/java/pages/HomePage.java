package pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import objectrepository.Locators;

public class HomePage {
	WebDriver driver;
	public HomePage(WebDriver driver) {
		this.driver=driver;
	}
	public void clicks() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(5));
		WebElement closepop = wait.until(ExpectedConditions.presenceOfElementLocated(Locators.closepop));
		closepop.click();

		WebDriverWait wait2 = new WebDriverWait(driver,Duration.ofSeconds(5));
		WebElement marketwatch = wait2.until(ExpectedConditions.presenceOfElementLocated(Locators.Marketwatch));
		marketwatch.click();
	}

}